# ASP.NET MVC5: JQuery Image Difference/Comparison Plugin

For detail tutorial Visit: http://bit.ly/2xg04Sw
