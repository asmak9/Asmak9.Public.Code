# ASP.NET Core: Entity Framework Call Store Procedure

For detail tutorial Visit: https://bit.ly/2C4BGYB
