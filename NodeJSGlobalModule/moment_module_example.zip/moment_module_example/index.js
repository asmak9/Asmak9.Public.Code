const moment = require('moment');

// Default Format 2025-06-02T13:30:09+05:00
console.log(moment().format());

// June 2nd 2025, 1:30:09 pm
console.log(moment().format('MMMM Do YYYY, h:mm:ss a'));

// Monday
console.log(moment().format('dddd'));

// Jun 2nd 25
console.log(moment().format("MMM Do YY"));