# Windows Phone: Dynamic Tile Design Generation

For detail tutorial Visit: https://bit.ly/2Dhwxg8
