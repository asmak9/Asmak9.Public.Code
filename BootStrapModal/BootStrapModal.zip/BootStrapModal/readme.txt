# ASP.NET MVC5: Lightbox Alternative Bootstrap Modal

For detail tutorial Visit: https://bit.ly/2T8Dwxq
