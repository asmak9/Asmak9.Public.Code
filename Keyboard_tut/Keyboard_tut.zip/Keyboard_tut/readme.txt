# Cocos2d-x - Enable Hardware Keyboard

For detail tutorial Visit: https://bit.ly/2B0mPgU
