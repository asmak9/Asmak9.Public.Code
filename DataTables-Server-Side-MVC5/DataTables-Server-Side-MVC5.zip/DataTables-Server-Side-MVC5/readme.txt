# ASP.NET MVC5: Datatables Plugin Server Side Integration

For detail tutorial Visit: https://bit.ly/3j5C0II
