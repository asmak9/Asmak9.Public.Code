# Setup Browser AI Agent using Python on Windows

For detail understanding Visit: https://rb.gy/mpmzct


Instructions:

Step-1: Change Directory Paths in the batch file according to your system. 
Step-2: Change Python Directory Paths in the batch file according to your system. 