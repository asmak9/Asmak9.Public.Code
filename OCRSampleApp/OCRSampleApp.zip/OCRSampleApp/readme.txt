# Windows Phone 8: Optical Character Recognition (OCR) library

For detail tutorial Visit: https://bit.ly/2FfHlhK
