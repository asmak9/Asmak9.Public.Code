# Cocos2d-XNA:Switch to Windows Phone 8 Native UI

For detail tutorial Visit: https://bit.ly/2T9uJLE
