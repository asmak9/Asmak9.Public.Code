# ASP.NET MVC5: Upload Image/File as File

For detail tutorial Visit: https://bit.ly/2BySQM9
