# ASP.NET MVC5: Buttons in Datatables Jquery plugin

For detail tutorial Visit: http://bit.ly/2CTSdvB
