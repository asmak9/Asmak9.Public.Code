# JavaScript: Date & Time Library Moment.JS

For detail tutorial Visit: http://bit.ly/2Fgnjj3
