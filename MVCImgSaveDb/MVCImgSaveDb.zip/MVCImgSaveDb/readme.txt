# ASP.NET MVC5: Upload Image/File into Database

For detail tutorial Visit: https://bit.ly/2AoN6DZ
