# Loading Sample Contacts Data on Windows Phone 8 (WP8) Emulator

For detail tutorial Visit: https://bit.ly/2T6A9qT
