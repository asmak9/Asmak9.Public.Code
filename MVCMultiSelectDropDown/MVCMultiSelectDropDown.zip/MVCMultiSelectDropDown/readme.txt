# ASP.NET MVC5: Bootstrap Style Multi Select Dropdown Plugin

For detail tutorial Visit: https://bit.ly/2KmxTYw
