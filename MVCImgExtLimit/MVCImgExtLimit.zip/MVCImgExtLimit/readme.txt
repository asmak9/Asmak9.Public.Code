# ASP.NET MVC5: Limit Upload File Type Extensions

For detail tutorial Visit: https://bit.ly/2A8Jx5D
