# ASP.NET Core: Entity Framework Query through Database

For detail tutorial Visit: https://bit.ly/2QUkDNH
