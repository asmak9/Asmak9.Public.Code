# Microsoft Cognitive Toolkit: Installation on Windows 7

For detail tutorial Visit: https://bit.ly/2ufBP6B
