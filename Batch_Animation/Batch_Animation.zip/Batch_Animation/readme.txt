# Cocos2d-x: Sprite Sheet Batch Rendering without PList

For detail tutorial Visit: https://bit.ly/2QDw384
