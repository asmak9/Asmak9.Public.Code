# Setup Browser AI Agent using Dockers

For detail understanding Visit: https://rb.gy/8gwq8a


Instructions:

Step-1: Change Directory Paths in the batch file according to your system. 