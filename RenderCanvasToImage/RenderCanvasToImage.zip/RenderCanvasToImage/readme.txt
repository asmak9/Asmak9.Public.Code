# Save Canvas UI Control to Image file in Windows 8.1

For detail tutorial Visit: https://bit.ly/2FSgE3h
